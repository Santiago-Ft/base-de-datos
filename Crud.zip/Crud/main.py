import tkinter as tk
from clase_cliente import Clientes
from clase_producto import Productos

def abrir_productos():
    Productos()

def abrir_clientes():
    Clientes()

root = tk.Tk()
root.title("Sistema de Gestión de Tienda")
root.geometry("300x200")

tk.Button(root, text="Gestión de Productos", command=abrir_productos).pack(pady=10)
tk.Button(root, text="Gestión de Clientes", command=abrir_clientes).pack(pady=10)

root.mainloop()