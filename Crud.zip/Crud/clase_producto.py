import tkinter as tk
from tkinter import messagebox
from clase_modulo_producto import Producto

productos = []

class Productos:
    def __init__(self):
        self.root = tk.Toplevel()
        self.root.title("Gestión de Productos")
        self.root.geometry("400x400")
        self.id = self.crear_entrada("ID")
        self.nombre = self.crear_entrada("Nombre")
        self.precio = self.crear_entrada("Precio")
        self.stock = self.crear_entrada("Stock")
        self.categoria = self.crear_entrada("Categoría")
        tk.Button(self.root, text="Agregar Producto", command=self.agregar_producto).pack(pady=5)
        tk.Button(self.root, text="Listar Productos", command=self.listar_productos).pack(pady=5)
        tk.Button(self.root, text="Eliminar Producto", command=self.eliminar_producto).pack(pady=5)
        self.lista_texto = tk.Text(self.root, height=10, width=40)
        self.lista_texto.pack(pady=10)
    def crear_entrada(self, label):
        tk.Label(self.root, text=label).pack()
        entry = tk.Entry(self.root)
        entry.pack()
        return entry
    def agregar_producto(self):
        """Agrega un producto a la base de datos."""
        id = self.id.get()
        nombre = self.nombre.get()
        precio = float(self.precio.get())
        stock = int(self.stock.get())
        categoria = self.categoria.get()
        producto = Producto()
        productos.append(producto)
        producto.agregar_producto(id, nombre, precio, stock, categoria)
        messagebox.showinfo("Éxito", "Producto agregado exitosamente.")
        self.limpiar_campos()
    def listar_productos(self):
        self.lista_texto.delete(1.0, tk.END)
        for prod in productos:
            self.lista_texto.insert(tk.END, f"{prod}\n")
        pass
    def eliminar_producto(self):
        id_a_eliminar = self.id.get()
        global productos
        productos = [p for p in productos if p["id"] != id_a_eliminar]
        messagebox.showinfo("Éxito", "Producto eliminado.")
        self.listar_productos()
        pass
    def limpiar_campos(self):
        self.id.delete(0, tk.END)
        self.nombre.delete(0, tk.END)
        self.precio.delete(0, tk.END)
        self.stock.delete(0, tk.END)
        self.categoria_entry.delete(0, tk.END)
        pass