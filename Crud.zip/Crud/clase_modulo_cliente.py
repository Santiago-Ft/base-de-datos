from clase_conexion import ConexionClientes

class ClienteModelo:
    def __init__(self):
        conexion_objeto = ConexionClientes()
        self.conexion = conexion_objeto.hacer_conexion()
        self.cursor = self.conexion.cursor()
        pass
    def insertar_cliente(self, cliente_data):
        sql_buscar = "SELECT id FROM Clientes WHERE id = %s"
        self.cursor.execute(sql_buscar, (cliente_data['id'],))
        resultado = self.cursor.fetchone()
        if resultado:
            print("El cliente con este ID ya existe. No se puede insertar.")
            respuesta = False
        else:
            sql_insertar = "INSERT INTO Clientes (id, nombre, apellidos, email, historial_compras) VALUES (%s, %s, %s, %s, %s)"
            valores = (
                cliente_data['id'],
                cliente_data['nombre'],
                cliente_data['apellidos'],
                cliente_data['email'],
                cliente_data['historial']
            )
            self.cursor.execute(sql_insertar, valores)
            self.conexion.commit()
            print("Cliente insertado correctamente.")
            respuesta = True
        self.cursor.close()
        self.conexion.close()
        return respuesta
