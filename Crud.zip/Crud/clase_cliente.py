import tkinter as tk
from tkinter import messagebox
from clase_modulo_cliente import ClienteModelo

clientes = []

class Clientes:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Gestión de Clientes")
        self.root.geometry("400x500")
        self.id = self.crear_entrada("ID")
        self.nombre = self.crear_entrada("Nombre")
        self.apellidos = self.crear_entrada("Apellidos")
        self.email = self.crear_entrada("Email")
        self.historial = self.crear_entrada("Historial de Compras")
        tk.Button(self.root, text="Agregar Cliente", command=self.agregar_cliente).pack(pady=5)
        tk.Button(self.root, text="Listar Clientes", command=self.listar_clientes).pack(pady=5)
        tk.Button(self.root, text="Eliminar Cliente", command=self.eliminar_cliente).pack(pady=5)
        self.lista_texto = tk.Text(self.root, height=10, width=40)
        self.lista_texto.pack(pady=10)
        self.root.mainloop()
        pass
    def crear_entrada(self, label):
        tk.Label(self.root, text=label).pack()
        entry = tk.Entry(self.root)
        entry.pack()
        return entry
    def agregar_cliente(self):
    cliente= {
        "id": self.id.get(),
        "nombre": self.nombre.get(),
        "apellidos": self.apellidos.get(),
        "email": self.email.get(),
        "historial": self.historial.get()
    }
    if not all(cliente.values()):
        messagebox.showerror("Error", "Todos los campos deben ser llenados.")
    else:
        cliente_db = ClienteModelo()
        cliente_db.agregar_cliente(cliente["id"], cliente["nombre"], cliente["apellidos"], cliente["email"], cliente["historial"])
        messagebox.showinfo("Éxito", "Cliente agregado exitosamente.")
        self.limpiar_campos()
        pass
    def listar_clientes(self):
        self.lista_texto.delete(1.0, tk.END)
        for cli in clientes:
            self.lista_texto.insert(tk.END, f"{cli}\n")
            pass
    def eliminar_cliente(self):
        id_a_eliminar = self.id.get()
        global clientes
        clientes = [c for c in clientes if c["id"] != id_a_eliminar]
        messagebox.showinfo("Éxito", "Cliente eliminado.")
        self.listar_clientes()
        pass
    def limpiar_campos(self):
        self.id.delete(0, tk.END)
        self.nombre.delete(0, tk.END)
        self.apellidos.delete(0, tk.END)
        self.email.delete(0, tk.END)
        self.historial.delete(0, tk.END)
        pass

