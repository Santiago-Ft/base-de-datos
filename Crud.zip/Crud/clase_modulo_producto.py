from clase_conexion import ConexionProductos

class Producto:
    def __init__(self):
        self.db = ConexionProductos()
        self.conexion = self.db.hacer_conexion()
    def agregar_producto(self, id, nombre, precio, stock, categoria):
        cursor = self.conexion.cursor()
        query = "INSERT INTO productos (id, nombre, precio, stock, categoria) VALUES (%s, %s, %s, %s, %s)"
        valores = (id, nombre, precio, stock, categoria)
        cursor.execute(query, valores)
        self.conexion.commit()
