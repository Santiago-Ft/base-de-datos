import mysql.connector


class ConexionClientes:
    def __init__(self):
        self.user = "root"
        self.password = ""
        self.database = "clientes"   
        self.host = "localhost"
        pass
    def hacer_conexion(self):
        conexion = mysql.connector.connect(host=self.host,database=self.database,user=self.user,password=self.password)
        if conexion.is_connected():
            print("conexion exitosa")
        else:
            print("conexion fallida")
        return conexion


class ConexionProductos:
    def __init__(self):
        self.user = "root"
        self.password = ""
        self.database = "productos"
        self.host = "localhost"
        pass
    def hacer_conexion(self):
        conexion = mysql.connector.connect(host=self.host,database=self.database,user=self.user,password=self.password)
        if conexion.is_connected():
            print("conexion exitosa")
        else:
            print("conexion fallida")
        return conexion